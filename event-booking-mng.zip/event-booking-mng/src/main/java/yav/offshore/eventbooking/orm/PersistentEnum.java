package yav.offshore.eventbooking.orm;

import java.util.Map;

/**
 * 
 * @author DEV-LongDT
 */
public interface PersistentEnum<T> {
	
	T getValue();
	
	String getDisplayName();

	Map<T, ? extends PersistentEnum<T>> getAll();
}
