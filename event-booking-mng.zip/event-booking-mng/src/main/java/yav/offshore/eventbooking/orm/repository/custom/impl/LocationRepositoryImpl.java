/**
 * 
 */
package yav.offshore.eventbooking.orm.repository.custom.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import yav.offshore.eventbooking.orm.entity.Location;
import yav.offshore.eventbooking.orm.query.LocationQuery;
import yav.offshore.eventbooking.orm.repository.custom.LocationRepositoryCustom;

/**
 * @author DEV-LongDT
 *
 */
@Repository
@Transactional(readOnly=true)
public class LocationRepositoryImpl implements LocationRepositoryCustom{
	@PersistenceContext
    EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public List<Location> findAllActiveLocation(LocationQuery query) {
		String sql = "select l from Location l where l.activeFlg = yav.offshore.eventbooking.orm.glossary.ActiveFlag.ACTIVE";
		Query sqlQuery = entityManager.createQuery(sql);
		sqlQuery.setFirstResult(query.getOffset());
		sqlQuery.setMaxResults(query.getPageSize());
		return sqlQuery.getResultList();
	}

	@Override
	public Long countLocation(LocationQuery query) {
		String sql = "select count(l) from Location l where l.activeFlg = yav.offshore.eventbooking.orm.glossary.ActiveFlag.ACTIVE";
		Query sqlQuery = entityManager.createQuery(sql);
		return (Long) sqlQuery.getSingleResult();
	}
}
