/**
 * 
 */
package yav.offshore.eventbooking.orm;

import java.io.Serializable;
import java.util.List;

/**
 * @author DEV-LongDT
 *
 */
public interface Page<T> extends Serializable {
	
	int getPageNo();
	
	int getPageSize();
	
	boolean hasMorePage();
	
	int getTotalPageCount();
	
	long getTotalRecordCount();
	
	List<? extends T> getRecords();
}
