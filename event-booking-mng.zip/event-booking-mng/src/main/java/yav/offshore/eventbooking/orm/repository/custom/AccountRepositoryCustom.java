/**
 * 
 */
package yav.offshore.eventbooking.orm.repository.custom;

import java.util.List;

import yav.offshore.eventbooking.orm.entity.Account;
import yav.offshore.eventbooking.orm.query.AccountQuery;

/**
 * @author DEV-LongDT
 *
 */
public interface AccountRepositoryCustom {
	List<Account> findAllActiveAccount(AccountQuery query);
	Long countAccount(AccountQuery query);
}
