/**
 * 
 */
package yav.offshore.eventbooking.validator;

import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import yav.offshore.eventbooking.orm.entity.Account;

/**
 * @author DEV-LongDT
 *
 */
public class LoginValidator implements Validator {
	
	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.equals(Account.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "error.require", new Object[]{new DefaultMessageSourceResolvable("account.email")});
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "error.require", new Object[]{new DefaultMessageSourceResolvable("account.password")});
	}

}
