package yav.offshore.eventbooking.orm.glossary;

import java.util.Map;

import yav.offshore.eventbooking.orm.PersistentEnum;
import yav.offshore.eventbooking.orm.PersistentEnums;

/**
 * 
 * @author DEV-LongDT
 */
public enum UsePersonalInfo implements PersistentEnum<Byte>{
	UNCHECKED((byte) 0, "UNCHECKED"),
	CHECKED((byte) 1, "CHECKED");

	private static final Map<Byte, UsePersonalInfo> INDEX = PersistentEnums.index(UsePersonalInfo.class);

    //
    private final byte value;
    private final String displayName;
    
    private UsePersonalInfo(byte value, String displayName) {
    	this.value = value;
        this.displayName = displayName;
	}
	
    @Override
    public Byte getValue() {
        return this.value;
    }

    @Override
    public String getDisplayName() {
        return this.displayName;
    }

    @Override
    public Map<Byte, UsePersonalInfo> getAll() {
        return INDEX;
    }
    
    public static UsePersonalInfo parse(Byte value) {
        return value == null ? null : INDEX.get(value);
    }

}
