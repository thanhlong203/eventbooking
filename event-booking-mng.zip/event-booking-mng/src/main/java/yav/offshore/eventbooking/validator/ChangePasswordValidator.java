/**
 * 
 */
package yav.offshore.eventbooking.validator;

import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import yav.offshore.eventbooking.orm.entity.Account;
import yav.offshore.eventbooking.orm.entity.NewAccount;
import yav.offshore.eventbooking.orm.service.AccountService;

/**
 * @author DEV-LongDT
 *
 */
public class ChangePasswordValidator implements Validator{
	private AccountService accountService;
	
	public ChangePasswordValidator(AccountService accountService) {
		super();
		this.accountService = accountService;
	}

	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.equals(NewAccount.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		NewAccount account = (NewAccount) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "newPassword", "error.require", new Object[]{new DefaultMessageSourceResolvable("account.new.password")});
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "error.require", new Object[]{new DefaultMessageSourceResolvable("account.old.password")});
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "confirmPassword", "error.require", new Object[]{new DefaultMessageSourceResolvable("account.confirm.password")});
		if (!account.getConfirmPassword().equals(account.getNewPassword())) {
			errors.rejectValue("newPassword", "error.correct", new Object[]{new DefaultMessageSourceResolvable("account.confirm.password")}, "");
			return;
		}
		Account acc = accountService.getById(account.getAccountId());
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		if (!passwordEncoder.matches(account.getPassword(), acc.getPassword())&& !"".equals(account.getPassword())) {
			errors.rejectValue("password", "error.correct", new Object[]{new DefaultMessageSourceResolvable("account.old.password")}, "");
			return;
		}
		if (passwordEncoder.matches(account.getNewPassword(), acc.getPassword())&& !"".equals(account.getNewPassword())) {
			errors.rejectValue("newPassword", "error.duplicate", new Object[]{new DefaultMessageSourceResolvable("account.old.password"), new DefaultMessageSourceResolvable("account.new.password")}, "");
		}
	}

}
