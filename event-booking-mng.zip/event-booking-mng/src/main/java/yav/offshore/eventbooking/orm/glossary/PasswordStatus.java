package yav.offshore.eventbooking.orm.glossary;

import java.util.Map;

import yav.offshore.eventbooking.orm.PersistentEnum;
import yav.offshore.eventbooking.orm.PersistentEnums;

/**
 * 
 * @author DEV-LongDT
 */
public enum PasswordStatus implements PersistentEnum<Byte>{
	INITIAL((byte) 1, "INNITIAL"),
	ACCEPTED((byte) 2, "ACCEPTED"),
	EXPIRED((byte) 3, "EXPIRED"),
	;

	private static final Map<Byte, PasswordStatus> INDEX = PersistentEnums.index(PasswordStatus.class);

    //
    private final byte value;
    private final String displayName;
    
    private PasswordStatus(byte value, String displayName) {
    	this.value = value;
        this.displayName = displayName;
	}
	
    @Override
    public Byte getValue() {
        return this.value;
    }

    @Override
    public String getDisplayName() {
        return this.displayName;
    }

    @Override
    public Map<Byte, PasswordStatus> getAll() {
        return INDEX;
    }
    
    public boolean isInitial() {
    	return this == INITIAL;
    }
    
    public boolean isAccepted() {
    	return this == ACCEPTED;
    }
    
    public boolean isExpired() {
    	return this == EXPIRED;
    }
    
    public static PasswordStatus parse(Byte value) {
        return value == null ? null : INDEX.get(value);
    }

}
