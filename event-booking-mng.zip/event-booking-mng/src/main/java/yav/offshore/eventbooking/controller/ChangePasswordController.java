/**
 * 
 */
package yav.offshore.eventbooking.controller;

import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import yav.offshore.eventbooking.controller.support.anotation.DoNotHaveToLogin;
import yav.offshore.eventbooking.controller.support.anotation.FreeAccess;
import yav.offshore.eventbooking.controller.support.anotation.LoginAccount;
import yav.offshore.eventbooking.misc.PassWordGenerator;
import yav.offshore.eventbooking.orm.entity.Account;
import yav.offshore.eventbooking.orm.entity.NewAccount;
import yav.offshore.eventbooking.orm.glossary.PasswordExpirePolicy;
import yav.offshore.eventbooking.orm.glossary.PasswordStatus;
import yav.offshore.eventbooking.validator.ChangePasswordValidator;

/**
 * @author DEV-LongDT
 *
 */
@Controller
@RequestMapping(value="/account")
public class ChangePasswordController extends AbstractController{

	@InitBinder
	public void initBinder(DataBinder binder) {
		binder.setValidator(new ChangePasswordValidator(accountService));
	}
	
	@GetMapping(value="change-password")
	@FreeAccess
	public String changePass(Model model, @LoginAccount Account account) {
		NewAccount acc = new NewAccount();
		acc.setAccountId(account.getAccountId());
		model.addAttribute("newAccount", acc);
		return "/account/changePassword";
	}
	
	@SuppressWarnings("deprecation")
	@PostMapping(value="change-password")
	@FreeAccess
	public String changePassword(@ModelAttribute("newAccount") @Valid NewAccount account, BindingResult bindingResult, Model model, @LoginAccount Account acc) {
		if (bindingResult.hasErrors()) {
			model.addAttribute("newAccount", account);
			return "/account/changePassword";
		}
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		acc.setPassword(passwordEncoder.encode(account.getNewPassword()));
		Date date = new Date();
		if (acc.getPasswordExpirePolicy() == PasswordExpirePolicy.ONE_YEAR) 
			date.setYear(date.getYear()+1);
		else if (acc.getPasswordExpirePolicy() == PasswordExpirePolicy.SIX_MONTH) 
			date.setMinutes(date.getMonth() + 6);
		else if (acc.getPasswordExpirePolicy() == PasswordExpirePolicy.THREE_YEARS) 
			date.setYear(date.getYear()+3);
		acc.setPasswordExpriedTime(date);
		acc.setPasswordStatus(PasswordStatus.ACCEPTED);
		accountService.insertOrUpdate(acc);
		return "redirect:/logout";
	}
	
	@DoNotHaveToLogin
	@GetMapping(value="forgot-password")
	public String forgotPassword() {
		return "/account/forgotPassword";
	}
	
	@DoNotHaveToLogin
	@PostMapping(value="forgot-password")
	public String forgotPassword(HttpServletRequest request, Model model, Locale locale) {
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String email = request.getParameter("email");
		Account account = accountService.getByEmail(email);
		if (account == null) {
			model.addAttribute("error", this.messageSource.getMessage("error.no.email", new Object[] {}, locale));
		} else {
			String newPassword = PassWordGenerator.generate(8);
			account.setPassword(passwordEncoder.encode(newPassword));
			account.setPasswordStatus(PasswordStatus.INITIAL);
			accountService.insertOrUpdate(account);
			// TODO Q&A
			sendEmail(email, "", newPassword, null);
			model.addAttribute("success", this.messageSource.getMessage("common.change.success", new Object[] {"Password"}, locale));
		}
		return "/account/forgotPassword";
	}
}
