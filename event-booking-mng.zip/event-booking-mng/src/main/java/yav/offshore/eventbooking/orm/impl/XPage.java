package yav.offshore.eventbooking.orm.impl;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import yav.offshore.eventbooking.orm.Page;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author DEV LongDT
 */
public final class XPage<T> implements Page<T> {
	//
	private static final long serialVersionUID = -5809680583529730511L;
	
	//
	private int pageNo;
	private int pageSize;
	private long totalRecordCount;
	private List<? extends T> records;
	
	/**
	 * 
	 */
	public XPage(int pageNo, int pageSize) {
		this.pageNo = pageNo;
		this.pageSize = pageSize;
		this.totalRecordCount = 0;
		this.records = new ArrayList<>(0);
	}
	
	public XPage(int pageNo, int pageSize, long totalSize) {
		this.pageNo = pageNo;
		this.pageSize = pageSize;
		this.records = new ArrayList<>(0);
		this.totalRecordCount = totalSize;
	}
	
	public XPage(int pageNo, int pageSize, long totalSize, List<? extends T> records) {
		this.pageNo = pageNo;
		this.records = records;
		this.pageSize = pageSize;
		this.totalRecordCount = totalSize;
	}

	/**
	 * 
	 */
	@Override
	public String toString() {
		return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
		.append("pageNo", pageNo)
		.append("pageSize", pageSize)
		.append("totalRecordCount", totalRecordCount)
		.append("recordCount", records == null ? 0 : records.size()).toString();
	}
	
	/**
	 * 
	 */
	@Override
	public boolean hasMorePage() {
		return getTotalPageCount() > this.pageNo;
	}
	
	@Override
	public int getTotalPageCount() {
		int r = (int)(this.totalRecordCount / this.pageSize);
		if(this.totalRecordCount % this.pageSize != 0) r += 1;
		return r;
	}
	
	/**
	 * 
	 */
	public int getPageNo() {
		return pageNo;
	}
	
	public void setPageNo(int start) {
		this.pageNo = start;
	}
	
	public int getPageSize() {
		return pageSize;
	}
	
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	
	public List<? extends T> getRecords() {
		return records;
	}

	public void setRecords(List<? extends T> records) {
		this.records = records;
	}
	
	public long getTotalRecordCount() {
		return totalRecordCount;
	}
	
	public void setTotalRecordCount(long totalRecordCount) {
		this.totalRecordCount = totalRecordCount;
	}
}
