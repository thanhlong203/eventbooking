package yav.offshore.eventbooking.interceptor;

import java.lang.reflect.Method;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import yav.offshore.eventbooking.controller.support.anotation.AjaxResponse;
import yav.offshore.eventbooking.controller.support.anotation.DoNotHaveToLogin;
import yav.offshore.eventbooking.controller.support.anotation.FreeAccess;
import yav.offshore.eventbooking.orm.entity.Account;
import yav.offshore.eventbooking.orm.glossary.PasswordStatus;

import org.springframework.web.method.HandlerMethod;

/**
 * @author DEV-LongDT
 *
 */

public class LoginInterceptor extends HandlerInterceptorAdapter{
	private final String CURRENT_USER = "current_user";
	
	@Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
		Method method = ((HandlerMethod) handler).getMethod();
		if (!method.isAnnotationPresent(DoNotHaveToLogin.class)) {
			if (request.getSession().getAttribute(CURRENT_USER) == null) {
				response.sendRedirect(request.getContextPath()+"/login");
				return false;
			}
			Account currentAccount = (Account) request.getSession().getAttribute(CURRENT_USER);
			if (!method.isAnnotationPresent(FreeAccess.class)&& (currentAccount.getPasswordStatus() == PasswordStatus.EXPIRED || currentAccount.getPasswordStatus() == PasswordStatus.INITIAL)) {
				response.sendRedirect(request.getContextPath()+"/account/change-password");
				return false;
			}
		}
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, //
            Object handler, ModelAndView modelAndView) throws Exception {
    	Method method = ((HandlerMethod) handler).getMethod();
		if (!method.isAnnotationPresent(AjaxResponse.class)) {
			Account account = (Account) request.getSession().getAttribute(CURRENT_USER);
			if (modelAndView != null) modelAndView.addObject("user", account);
		}
 
    }
 
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, //
            Object handler, Exception ex) throws Exception {
//        System.out.println("\n-------- LogInterception.afterCompletion --- ");
// 
//        long startTime = (Long) request.getAttribute("startTime");
//        long endTime = System.currentTimeMillis();
//        System.out.println("Request URL: " + request.getRequestURL());
//        System.out.println("End Time: " + endTime);
//// 
//        System.out.println("Time Taken: " + (endTime - startTime));
    }
 
}
