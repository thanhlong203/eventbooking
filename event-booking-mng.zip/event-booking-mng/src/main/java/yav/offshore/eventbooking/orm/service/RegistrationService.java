package yav.offshore.eventbooking.orm.service;

import java.util.List;

import yav.offshore.eventbooking.orm.entity.Registration;

/**
 * @author DEV-LongDT
 *
 */
public interface RegistrationService {
	List<Registration> getAll();
	List<Registration> getByLocationId(Integer id);
}
