/**
 * 
 */
package yav.offshore.eventbooking.orm.entity;

/**
 * @author DEV-LongDT
 *
 */
public class XSchedule {
	private String date;
	private String fromTime;
	private String toTime;
	private Integer participantLimit;
	private Integer locationId;
	/**
	 * @return the date
	 */
	public String getDate() {
		return date;
	}
	/**
	 * @param date the date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}
	/**
	 * @return the fromTime
	 */
	public String getFromTime() {
		return fromTime;
	}
	/**
	 * @param fromTime the fromTime to set
	 */
	public void setFromTime(String fromTime) {
		this.fromTime = fromTime;
	}
	/**
	 * @return the toTime
	 */
	public String getToTime() {
		return toTime;
	}
	/**
	 * @param toTime the toTime to set
	 */
	public void setToTime(String toTime) {
		this.toTime = toTime;
	}
	/**
	 * @return the participantLimit
	 */
	public Integer getParticipantLimit() {
		return participantLimit;
	}
	/**
	 * @param participantLimit the participantLimit to set
	 */
	public void setParticipantLimit(Integer participantLimit) {
		this.participantLimit = participantLimit;
	}
	/**
	 * @return the locationId
	 */
	public Integer getLocationId() {
		return locationId;
	}
	/**
	 * @param locationId the locationId to set
	 */
	public void setLocationId(Integer locationId) {
		this.locationId = locationId;
	}
}
