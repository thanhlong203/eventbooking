/**
 * 
 */
package yav.offshore.eventbooking.orm.repository.custom;

import java.util.List;

import yav.offshore.eventbooking.orm.entity.Location;
import yav.offshore.eventbooking.orm.query.LocationQuery;

/**
 * @author DEV-LongDT
 *
 */
public interface LocationRepositoryCustom {
	List<Location> findAllActiveLocation(LocationQuery query);
	Long countLocation(LocationQuery query);
}
