/**
 * 
 */
package yav.offshore.eventbooking.validator;

import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

/**
 * @author DEV-LongDT
 *
 */
public class LocationValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		return true;
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "error.require", new Object[]{new DefaultMessageSourceResolvable("location.name")});
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "address", "error.require", new Object[]{new DefaultMessageSourceResolvable("location.address")});
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "url", "error.require", new Object[]{new DefaultMessageSourceResolvable("location.url")});
	}

}
