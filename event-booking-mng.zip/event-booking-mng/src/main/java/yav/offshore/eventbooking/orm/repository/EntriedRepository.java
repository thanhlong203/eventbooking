package yav.offshore.eventbooking.orm.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import yav.offshore.eventbooking.orm.entity.Entried;
import yav.offshore.eventbooking.orm.repository.custom.EntriedRepositoryCustom;

@Repository
public interface EntriedRepository extends CrudRepository<Entried, Integer>, EntriedRepositoryCustom {
}
