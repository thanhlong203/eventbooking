package yav.offshore.eventbooking.orm.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import yav.offshore.eventbooking.orm.Page;
import yav.offshore.eventbooking.orm.entity.Account;
import yav.offshore.eventbooking.orm.impl.XPage;
import yav.offshore.eventbooking.orm.query.AccountQuery;
import yav.offshore.eventbooking.orm.repository.AccountRepository;
import yav.offshore.eventbooking.orm.service.AccountService;

@Service
public class AccountServiceImpl implements AccountService{
	@Autowired
	private AccountRepository accountRepository;
		
	@Override
	public void insertOrUpdate(Account account) {
		accountRepository.save(account);
	}

	@Override
	public Account authenLogin(String email, String password) {
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		Account account = accountRepository.findByEmail(email);
		return account != null && passwordEncoder.matches(password, account.getPassword()) ? account : null;
	}

	@Override
	public Account getById(int id) {
		return accountRepository.findOne(id);
	}

	@Override
	public Account getByEmail(String email) {
		return accountRepository.findByEmail(email);
	}

	@Override
	public Page<Account> paginateAccount(AccountQuery query) {
		final XPage<Account> r = new XPage<>(query.getPageNo(), query.getPageSize());
		r.setRecords(accountRepository.findAllActiveAccount(query));
		r.setTotalRecordCount(accountRepository.countAccount(query));
		return r;
	}

	@Override
	public void save(Account account) {
		accountRepository.save(account);
	}

}
