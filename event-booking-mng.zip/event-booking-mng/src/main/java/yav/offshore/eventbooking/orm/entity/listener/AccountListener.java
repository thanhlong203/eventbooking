package yav.offshore.eventbooking.orm.entity.listener;

import java.util.Date;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import yav.offshore.eventbooking.orm.entity.Account;
import yav.offshore.eventbooking.orm.glossary.PasswordExpirePolicy;
import yav.offshore.eventbooking.orm.glossary.PasswordStatus;

public class AccountListener {
	
	@PrePersist
	@PreUpdate
	public void methodExecuteBeforeSave(final Account account) {
		if (account.getAccountId() == null) {
			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			account.setPassword(passwordEncoder.encode(account.getPassword()));
			account.setInsertDatetime(new Date());
			account.setRegisterDate(new Date());
			account.setPasswordStatus(PasswordStatus.INITIAL);
			account.setPasswordExpirePolicy(PasswordExpirePolicy.NEVER);
		}
		account.setUpdateDatetime(new Date());
	}
}
