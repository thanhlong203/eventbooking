package yav.offshore.eventbooking.orm.glossary;

import java.util.Map;

import yav.offshore.eventbooking.orm.PersistentEnum;
import yav.offshore.eventbooking.orm.PersistentEnums;

/**
 * 
 * @author DEV-LongDT
 */
public enum Gender implements PersistentEnum<Byte>{
	FEAMALE((byte) 0, "FEMAIL"),
	MALE((byte) 1, "MALE"),
	OTHER((byte) 2, "OTHER");

	private static final Map<Byte, Gender> INDEX = PersistentEnums.index(Gender.class);

    //
    private final byte value;
    private final String displayName;
    
    private Gender(byte value, String displayName) {
    	this.value = value;
        this.displayName = displayName;
	}
	
    @Override
    public Byte getValue() {
        return this.value;
    }

    @Override
    public String getDisplayName() {
        return this.displayName;
    }

    @Override
    public Map<Byte, Gender> getAll() {
        return INDEX;
    }
    
    public static Gender parse(Byte value) {
        return value == null ? null : INDEX.get(value);
    }

}
