package yav.offshore.eventbooking.orm.glossary;

import java.util.Map;

import yav.offshore.eventbooking.orm.PersistentEnum;
import yav.offshore.eventbooking.orm.PersistentEnums;

/**
 * 
 * @author DEV-LongDT
 */
public enum PasswordExpirePolicy implements PersistentEnum<Byte>{
	NEVER((byte) 0, "never"),
	SIX_MONTH((byte) 1, "six month"),
	ONE_YEAR((byte) 2, "1 year"),
	THREE_YEARS((byte) 3, "3 years"),
	
	;

	private static final Map<Byte, PasswordExpirePolicy> INDEX = PersistentEnums.index(PasswordExpirePolicy.class);

    //
    private final byte value;
    private final String displayName;
    
    private PasswordExpirePolicy(byte value, String displayName) {
    	this.value = value;
        this.displayName = displayName;
	}
	
    @Override
    public Byte getValue() {
        return this.value;
    }

    @Override
    public String getDisplayName() {
        return this.displayName;
    }

    @Override
    public Map<Byte, PasswordExpirePolicy> getAll() {
        return INDEX;
    }
    
    public boolean isNever() {
    	return this == NEVER;
    }
    
    public boolean isSixMonth() {
    	return this == SIX_MONTH;
    }
    
    public boolean isOneYear() {
    	return this == ONE_YEAR;
    }
    
    public boolean isThreeYear() {
    	return this == THREE_YEARS;
    }
    
    public static PasswordExpirePolicy parse(Byte value) {
        return value == null ? null : INDEX.get(value);
    }

}
