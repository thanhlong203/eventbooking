/**
 * 
 */
package yav.offshore.eventbooking.orm.service;

import yav.offshore.eventbooking.orm.Page;
import yav.offshore.eventbooking.orm.entity.Entried;
import yav.offshore.eventbooking.orm.query.EntriedQuery;

/**
 * @author DEV-LongDT
 *
 */
public interface EntriedService {
	Page<Entried> paginateEntried(EntriedQuery query); 
}
