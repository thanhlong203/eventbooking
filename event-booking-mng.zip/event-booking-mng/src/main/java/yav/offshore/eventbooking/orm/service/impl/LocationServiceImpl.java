/**
 * 
 */
package yav.offshore.eventbooking.orm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import yav.offshore.eventbooking.orm.Page;
import yav.offshore.eventbooking.orm.entity.Location;
import yav.offshore.eventbooking.orm.impl.XPage;
import yav.offshore.eventbooking.orm.query.LocationQuery;
import yav.offshore.eventbooking.orm.repository.LocationRepository;
import yav.offshore.eventbooking.orm.service.LocationService;

/**
 * @author DEV-LongDT
 *
 */

@Service
public class LocationServiceImpl implements LocationService{
	@Autowired
	private LocationRepository locationRepository;

	@Override
	public Location getLocation(Integer locationId) {
		return locationRepository.findLocationById(locationId);
	}

	@Override
	public void save(Location location) {
		locationRepository.save(location);
	}

	@Override
	public void delete(Integer locationId) {
		locationRepository.delete(locationId);
	}

	@Override
	public Page<Location> paginateLocation(LocationQuery query) {
		XPage<Location> r = new XPage<>(query.getPageNo(), query.getPageSize());
		r.setRecords(locationRepository.findAllActiveLocation(query));
		r.setTotalRecordCount(locationRepository.countLocation(query));
		return r;
	}

	@Override
	public List<Location> getAll() {
		return locationRepository.findAll();
	}
}
