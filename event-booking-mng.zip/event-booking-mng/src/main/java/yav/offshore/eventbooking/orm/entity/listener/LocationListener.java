package yav.offshore.eventbooking.orm.entity.listener;

import java.util.Date;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import yav.offshore.eventbooking.orm.entity.Location;

public class LocationListener {
	
	@PrePersist
	@PreUpdate
	public void methodExecuteBeforeSave(final Location location) {
		if (location.getLocationId() == null) {
			location.setInsertDatetime(new Date());
			location.setModifiedDatetime(new Date());
		}
		location.setUpdateDatetime(new Date());
	}
}
