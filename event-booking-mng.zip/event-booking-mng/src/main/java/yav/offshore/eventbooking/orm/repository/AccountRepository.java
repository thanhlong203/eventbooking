package yav.offshore.eventbooking.orm.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import yav.offshore.eventbooking.orm.entity.Account;
import yav.offshore.eventbooking.orm.repository.custom.AccountRepositoryCustom;

@Repository
public interface AccountRepository extends CrudRepository<Account, Integer>, AccountRepositoryCustom{
	Account findByEmail(String email);
}
