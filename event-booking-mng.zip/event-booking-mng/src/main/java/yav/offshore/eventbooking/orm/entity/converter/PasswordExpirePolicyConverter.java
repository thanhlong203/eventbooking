/**
 * 
 */
package yav.offshore.eventbooking.orm.entity.converter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import yav.offshore.eventbooking.orm.glossary.PasswordExpirePolicy;

/**
 * @author DEV-LongDT
 *
 */
@Converter(autoApply = true)
public class PasswordExpirePolicyConverter implements AttributeConverter<PasswordExpirePolicy, Integer> {

	@Override
	public Integer convertToDatabaseColumn(PasswordExpirePolicy passwordExpirePolicy) {
		return passwordExpirePolicy.getValue().intValue();
	}

	@Override
	public PasswordExpirePolicy convertToEntityAttribute(Integer dbData) {
		return PasswordExpirePolicy.parse(dbData.byteValue());
	}

}
