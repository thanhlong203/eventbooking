/**
 * 
 */
package yav.offshore.eventbooking.orm.repository.custom.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import yav.offshore.eventbooking.orm.entity.Account;
import yav.offshore.eventbooking.orm.query.AccountQuery;
import yav.offshore.eventbooking.orm.repository.custom.AccountRepositoryCustom;

/**
 * @author DEV-LongDT
 *
 */
@Repository
@Transactional(readOnly=true)
public class AccountRepositoryImpl implements AccountRepositoryCustom{
	@PersistenceContext
    EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public List<Account> findAllActiveAccount(AccountQuery query) {
		String sql = "select a from Account a where a.activeFlg = yav.offshore.eventbooking.orm.glossary.ActiveFlag.ACTIVE";
		Query sqlQuery = entityManager.createQuery(sql);
		sqlQuery.setFirstResult(query.getOffset());
		sqlQuery.setMaxResults(query.getPageSize());
		return sqlQuery.getResultList();
	}

	@Override
	public Long countAccount(AccountQuery query) {
		String sql = "select count(a) from Account a where a.activeFlg = yav.offshore.eventbooking.orm.glossary.ActiveFlag.ACTIVE";
		Query sqlQuery = entityManager.createQuery(sql);
		return (Long) sqlQuery.getSingleResult();
	}
}
