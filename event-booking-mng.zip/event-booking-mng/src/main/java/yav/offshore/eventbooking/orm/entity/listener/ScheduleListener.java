/**
 * 
 */
package yav.offshore.eventbooking.orm.entity.listener;

import java.util.Date;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import yav.offshore.eventbooking.orm.entity.Schedule;
import yav.offshore.eventbooking.orm.glossary.ActiveFlag;

/**
 * @author DEV-LongDT
 *
 */
public class ScheduleListener {
	
	@PrePersist
	@PreUpdate
	public void methodExecuteBeforeSave(final Schedule schedule) {
		schedule.setActiveFlg(ActiveFlag.ACTIVE);
		schedule.setModifiedDatetime(new Date());
		if (schedule.getScheduleId() == null) schedule.setInsertDatetime(new Date());
	}
}
