/**
 * 
 */
package yav.offshore.eventbooking.orm.service;

import java.util.List;

import yav.offshore.eventbooking.orm.Page;
import yav.offshore.eventbooking.orm.entity.Location;
import yav.offshore.eventbooking.orm.query.LocationQuery;

/**
 * @author DEV-LongDT
 *
 */
public interface LocationService {
	Page<Location> paginateLocation(LocationQuery query);
	Location getLocation(Integer locationId);
	void save(Location location);
	void delete(Integer locationId);
	List<Location> getAll();
}
