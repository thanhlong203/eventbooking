/**
 * 
 */
package yav.offshore.eventbooking.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import yav.offshore.eventbooking.controller.support.anotation.LoginAccount;
import yav.offshore.eventbooking.orm.entity.Account;
import yav.offshore.eventbooking.orm.entity.Location;
import yav.offshore.eventbooking.orm.glossary.ActiveFlag;
import yav.offshore.eventbooking.orm.query.LocationQuery;
import yav.offshore.eventbooking.validator.LocationValidator;

/**
 * @author DEV-LongDT
 *
 */
@Controller
@RequestMapping(value="/location")
public class LocationController extends AbstractController {
	
	@InitBinder
	public void initBinder(DataBinder binder) {
		binder.setValidator(new LocationValidator());
	}
	
	@GetMapping(value="")
	public String index(Model model, @RequestParam(value = "id", required = false) Integer id, @RequestParam(value = "pageNo", required = false) Integer pageNo, @RequestParam(value = "pageSize", required = false) Integer pageSize) {
		LocationQuery query = new LocationQuery();
		query.setPageNo(pageSize == null ? 1 : pageNo);
		query.setPageSize(pageSize == null ? 25 : pageSize);
		model.addAttribute("location", id == null ? new Location() : locationService.getLocation(id));
		model.addAttribute("page", locationService.paginateLocation(query));
		model.addAttribute("pageSize", query.getPageNo());
		model.addAttribute("pageSize", query.getPageSize());
		return "location/index";
	}
	
	@PostMapping(value="/edit")
	public String edit(@ModelAttribute("location") @Valid Location location, BindingResult bindingResult, Model model, @LoginAccount Account account) {
		if (bindingResult.hasErrors()) {
			LocationQuery query = new LocationQuery();
			query.setPageNo(1);
			query.setPageSize(25);
			model.addAttribute("location", location);
			model.addAttribute("page", locationService.paginateLocation(query));
			model.addAttribute("pageSize", query.getPageNo());
			model.addAttribute("pageSize", query.getPageSize());
			return "/location/index";
		} else {
			if (location.getLocationId() == null) {
				location.setAccountId(account.getAccountId());
				location.setActiveFlg(ActiveFlag.ACTIVE);
				locationService.save(location);
			} else {
				Location dbLocation = locationService.getLocation(location.getLocationId());
				dbLocation.setAddress(location.getAddress());
				dbLocation.setName(location.getName());
				dbLocation.setUrl(location.getUrl());
				locationService.save(dbLocation);
			}
		}
		return "redirect:/location";
	}
	
	@GetMapping(value="/delete/{id}")
	public String delete(@PathVariable Integer id) {
		Location location = locationService.getLocation(id);
		if (location != null)	locationService.delete(id);
		return "redirect:/location";
	}
}
