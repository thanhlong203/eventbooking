/**
 * 
 */
package yav.offshore.eventbooking.orm.entity.converter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import yav.offshore.eventbooking.orm.glossary.ActiveFlag;

/**
 * @author DEV-LongDT
 *
 */
@Converter(autoApply = true)
public class ActiveFlagConverter implements AttributeConverter<ActiveFlag, Integer> {

	@Override
	public Integer convertToDatabaseColumn(ActiveFlag activeFlag) {
		return activeFlag.getValue().intValue();
	}

	@Override
	public ActiveFlag convertToEntityAttribute(Integer dbData) {
		return ActiveFlag.parse(dbData.byteValue());
	}

}
