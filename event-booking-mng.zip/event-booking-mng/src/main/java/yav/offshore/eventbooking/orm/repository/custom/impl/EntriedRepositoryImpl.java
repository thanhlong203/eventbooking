/**
 * 
 */
package yav.offshore.eventbooking.orm.repository.custom.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import yav.offshore.eventbooking.orm.entity.Entried;
import yav.offshore.eventbooking.orm.glossary.EntriedStatus;
import yav.offshore.eventbooking.orm.query.EntriedQuery;
import yav.offshore.eventbooking.orm.repository.custom.EntriedRepositoryCustom;

/**
 * @author DEV-LongDT
 *
 */
@Repository
@Transactional(readOnly=true)
public class EntriedRepositoryImpl implements EntriedRepositoryCustom{
	@PersistenceContext
    EntityManager entityManager;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Entried> getEntried(EntriedQuery query) {
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT e FROM Entried e left join e.attendee a WHERE e.activeFlg = yav.offshore.eventbooking.orm.glossary.ActiveFlag.ACTIVE");
		sql.append(getSqlQuery(query));
		Query sqlQuery = entityManager.createQuery(sql.toString());
		sqlQuery.setFirstResult(query.getOffset());
		sqlQuery.setMaxResults(query.getPageSize());
		return sqlQuery.getResultList();
	}

	@Override
	public Long countEntried(EntriedQuery query) {
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT COUNT(e) FROM Entried e left join e.attendee a WHERE e.activeFlg = yav.offshore.eventbooking.orm.glossary.ActiveFlag.ACTIVE");
		sql.append(getSqlQuery(query));
		Query sqlQuery = entityManager.createQuery(sql.toString());
		return (Long) sqlQuery.getSingleResult();
	}
	
	public String getSqlQuery(EntriedQuery query) {
		StringBuffer sql = new StringBuffer();
		if (query.getLocationId() != null) sql.append(" AND e.locationId = ").append(query.getLocationId());
		if (query.getDateFrom() != null) sql.append(" AND e.scheduleDate >= ").append(query.getDateFrom());
		if (query.getDateTo() != null) sql.append(" AND e.scheduleDate <= ").append(query.getDateTo());
		if (query.getEntriesStatus() != null) {
			if (query.getEntriesStatus() == EntriedStatus.RESERVED) sql.append(" AND e.status = yav.offshore.eventbooking.orm.glossary.EntriedStatus.RESERVED");
			if (query.getEntriesStatus() == EntriedStatus.CANCEL) sql.append(" AND e.status = yav.offshore.eventbooking.orm.glossary.EntriedStatus.CANCEL");
		}
		return sql.toString();
	}
}
