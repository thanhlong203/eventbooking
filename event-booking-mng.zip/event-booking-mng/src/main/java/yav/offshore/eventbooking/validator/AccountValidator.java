/**
 * 
 */
package yav.offshore.eventbooking.validator;

import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import yav.offshore.eventbooking.orm.entity.Account;
import yav.offshore.eventbooking.orm.service.AccountService;

/**
 * @author DEV-LongDT
 *
 */
public class AccountValidator implements Validator{
	private AccountService accountService;
	
	/**
	 * @param accountService
	 */
	public AccountValidator(AccountService accountService) {
		super();
		this.accountService = accountService;
	}

	@Override
	public boolean supports(Class<?> clazz) {
		return true;
	}

	@Override
	public void validate(Object target, Errors errors) {
		Account account = (Account) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "error.require", new Object[]{new DefaultMessageSourceResolvable("account.email")});
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "fullName", "error.require", new Object[]{new DefaultMessageSourceResolvable("account.fullname")});
		if (accountService.getByEmail(account.getEmail()) != null) errors.rejectValue("email", "error.dupplicate", new Object[]{new DefaultMessageSourceResolvable("account.email")}, "");
	}

}
