/**
 * 
 */
package yav.offshore.eventbooking.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import yav.offshore.eventbooking.controller.support.anotation.LoginAccount;
import yav.offshore.eventbooking.orm.entity.Account;

/**
 * @author DEV-LongDT
 *
 */

@Controller
public class PolicyController {

	@RequestMapping(value="/policy", method=RequestMethod.GET)
	public String policy(@LoginAccount Account acc, HttpSession session) {
		return "policy";
	}
}
