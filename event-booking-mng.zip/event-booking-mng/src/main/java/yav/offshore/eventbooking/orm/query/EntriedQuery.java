/**
 * 
 */
package yav.offshore.eventbooking.orm.query;

import yav.offshore.eventbooking.orm.glossary.EntriedStatus;

/**
 * @author DEV-LongDT
 *
 */
public class EntriedQuery extends AbstractQuery {
	private Integer locationId;
	private String dateFrom;
	private String dateTo;
	private EntriedStatus entriesStatus;
	/**
	 * @return the locationId
	 */
	public Integer getLocationId() {
		return locationId;
	}
	/**
	 * @param locationId the locationId to set
	 */
	public void setLocationId(Integer locationId) {
		this.locationId = locationId;
	}
	/**
	 * @return the dateFrom
	 */
	public String getDateFrom() {
		return dateFrom;
	}
	/**
	 * @param dateFrom the dateFrom to set
	 */
	public void setDateFrom(String dateFrom) {
		this.dateFrom = dateFrom;
	}
	/**
	 * @return the dateTo
	 */
	public String getDateTo() {
		return dateTo;
	}
	/**
	 * @param dateTo the dateTo to set
	 */
	public void setDateTo(String dateTo) {
		this.dateTo = dateTo;
	}
	/**
	 * @return the entriesStatus
	 */
	public EntriedStatus getEntriesStatus() {
		return entriesStatus;
	}
	/**
	 * @param entriesStatus the entriesStatus to set
	 */
	public void setEntriesStatus(EntriedStatus entriesStatus) {
		this.entriesStatus = entriesStatus;
	}
}
