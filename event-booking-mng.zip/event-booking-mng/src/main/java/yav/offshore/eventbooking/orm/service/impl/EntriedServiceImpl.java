/**
 * 
 */
package yav.offshore.eventbooking.orm.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import yav.offshore.eventbooking.orm.Page;
import yav.offshore.eventbooking.orm.entity.Entried;
import yav.offshore.eventbooking.orm.impl.XPage;
import yav.offshore.eventbooking.orm.query.EntriedQuery;
import yav.offshore.eventbooking.orm.repository.EntriedRepository;
import yav.offshore.eventbooking.orm.service.EntriedService;

/**
 * @author DEV-LongDT
 *
 */
@Service
public class EntriedServiceImpl implements EntriedService {
	@Autowired
	private EntriedRepository entriedRepository;

	@Override
	public Page<Entried> paginateEntried(EntriedQuery query) {
		final XPage<Entried> r = new XPage<Entried>(query.getPageNo(), query.getPageSize());
		r.setRecords(entriedRepository.getEntried(query));
		r.setTotalRecordCount(entriedRepository.countEntried(query));
		return r;
	}
	
	
}
