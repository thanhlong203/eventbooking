/**
 * 
 */
package yav.offshore.eventbooking.orm.query;

/**
 * @author DEV-LongDT
 *
 */
public class LocationQuery extends AbstractQuery{

}
