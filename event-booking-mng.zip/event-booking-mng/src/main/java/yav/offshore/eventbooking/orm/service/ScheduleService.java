/**
 * 
 */
package yav.offshore.eventbooking.orm.service;

import java.util.List;

import yav.offshore.eventbooking.orm.Page;
import yav.offshore.eventbooking.orm.entity.Schedule;
import yav.offshore.eventbooking.orm.query.ScheduleQuery;

/**
 * @author DEV-LongDT
 *
 */

public interface ScheduleService {
	List<Schedule> getScheduleLocation(int locationId);
	Page<Schedule> paginateSchedule(ScheduleQuery query); 
	void save(Schedule schedule);
	void saveMany(Iterable<Schedule> schedulerable);
}
