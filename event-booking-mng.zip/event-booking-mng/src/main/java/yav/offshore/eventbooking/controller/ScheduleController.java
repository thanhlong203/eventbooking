/**
 * 
 */
package yav.offshore.eventbooking.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import yav.offshore.eventbooking.controller.support.anotation.AjaxResponse;
import yav.offshore.eventbooking.controller.support.anotation.LoginAccount;
import yav.offshore.eventbooking.orm.entity.Account;
import yav.offshore.eventbooking.orm.entity.Location;
import yav.offshore.eventbooking.orm.entity.Schedule;
import yav.offshore.eventbooking.orm.entity.XSchedule;
import yav.offshore.eventbooking.orm.query.ScheduleQuery;

/**
 * @author DEV-LongDT
 *
 */

@Controller
@RequestMapping(value="/schedule")
public class ScheduleController extends AbstractController{
	private static final Logger LOGGER = LoggerFactory.getLogger(ScheduleController.class);
	
	@GetMapping(value="")
	public String schedule(Model model, @RequestParam(value = "location", required = false) String location, @RequestParam(value = "datefrom", required = false) String datefrom, @RequestParam(value = "dateto", required = false) String dateto,
			@RequestParam(value = "pageNo", defaultValue="1") Integer pageNo, @RequestParam(value = "pageSize", defaultValue="25") Integer pageSize, Locale locale) {
		List<Location> locations = locationService.getAll();
		model.addAttribute("locations", locations);
		if (checkParam(location, datefrom, dateto, model, locale)) {
			ScheduleQuery query = new ScheduleQuery();
			query.setLocationId(location == null ? locations.get(0).getLocationId() : Integer.parseInt(location));
			query.setDateFrom(!"".equals(datefrom) && datefrom != null ? datefrom : null);
			query.setDateTo(!"".equals(dateto) && dateto != null ? dateto : null);
			query.setPageNo(pageNo);
			query.setPageSize(pageSize);
			model.addAttribute("page", scheduleService.paginateSchedule(query));
			model.addAttribute("pageNo", query.getPageNo());
			model.addAttribute("pageSize", pageSize);
			model.addAttribute("datefrom", datefrom);
			model.addAttribute("dateto", dateto);
		}
		return "/schedule/index";
	}
	
	@GetMapping(value="/add")
	public String add(Model model) {
		List<Location> locations = locationService.getAll();
		model.addAttribute("locations", locations);
		return "/schedule/add";
	}
	
	@PostMapping(value="/save")
	@AjaxResponse
	public @ResponseBody String save(@RequestBody List<XSchedule> schedules, @LoginAccount Account account) {
		try {
			Location location = new Location();
			if (schedules.size() > 6) return "error";
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyy-mm-dd"); 
			SimpleDateFormat hr = new SimpleDateFormat("hh : mm"); 
			List<Schedule> lst = new ArrayList<>();
			for (XSchedule s : schedules) {
				if (!isDate(s.getDate())) return "error";
				Schedule r = new Schedule();
				r.setAccountId(account.getAccountId());
				r.setDate(sdf.parse(s.getDate()));
				r.setFromTime(hr.parse(s.getFromTime()));
				r.setToTime(hr.parse(s.getToTime()));
				location.setLocationId(s.getLocationId());
				r.setLocation(location);
				r.setParticipantLimit(s.getParticipantLimit());
				lst.add(r);
			}
			Iterable<Schedule> schedulerable = lst;
			scheduleService.saveMany(schedulerable);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage());
			return "error";
		}
		return "success";
	}
	
	private boolean checkParam(String location, String datefrom, String dateTo, Model model, Locale locale) {
		if (location != null && !NumberUtils.isNumber(location)) {
			model.addAttribute("error", this.messageSource.getMessage("error.not.number", new Object[] {"location.id"}, locale));
			return false;
		}
		if (datefrom != null && !"".equals(datefrom) && !isDate(datefrom)) {
			model.addAttribute("error", this.messageSource.getMessage("error.not.date", new Object[] {"common.datefrom"}, locale));
			return false;
		}
		if (dateTo != null && !"".equals(datefrom) && !isDate(dateTo)) {
			model.addAttribute("error", this.messageSource.getMessage("error.not.date", new Object[] {"common.dateto"}, locale));
			return false;
		}
		return true;
	}
	
}
