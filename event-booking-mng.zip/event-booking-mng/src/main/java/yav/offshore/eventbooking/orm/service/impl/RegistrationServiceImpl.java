package yav.offshore.eventbooking.orm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;

import yav.offshore.eventbooking.orm.entity.Registration;
import yav.offshore.eventbooking.orm.repository.RegistrationRepository;
import yav.offshore.eventbooking.orm.service.RegistrationService;

/**
 * @author DEV-LongDT
 *
 */
@Service
public class RegistrationServiceImpl implements RegistrationService{
	@Autowired
	private RegistrationRepository registrationRepository;

	@Override
	public List<Registration> getAll() {
		return Lists.newArrayList(registrationRepository.findAll());
	}

	@Override
	public List<Registration> getByLocationId(Integer id) {
		return registrationRepository.getByLocationId(id);
	}
	
}
