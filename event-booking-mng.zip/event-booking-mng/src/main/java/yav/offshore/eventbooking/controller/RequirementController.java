/**
 * 
 */
package yav.offshore.eventbooking.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import yav.offshore.eventbooking.orm.query.EntriedQuery;

/**
 * @author DEV-LongDT
 *
 */
@Controller
@RequestMapping(value="/requirement")
public class RequirementController extends AbstractController {
	
	@GetMapping(value="/status")
	public String status(Model model, @RequestParam Map<String, String> reqParam ) {
		if (reqParam.size() > 0) {
			if (validate()) {
				EntriedQuery query = new EntriedQuery();
				query.setDateFrom("".equals(reqParam.get("datefrom"))? null : reqParam.get("datefrom"));
				query.setDateTo("".equals(reqParam.get("dateto"))? null : reqParam.get("dateto"));
				if (!reqParam.containsKey("pageNo")) query.setPageNo(1);
				else query.setPageNo("".equals(reqParam.get("pageNo")) ? null : Integer.parseInt(reqParam.get("pageNo")));
				if (!reqParam.containsKey("pageSize")) query.setPageSize(25);
				else query.setPageSize("".equals(reqParam.get("pageSize")) ? null : Integer.parseInt(reqParam.get("pageSize")));
				model.addAttribute("page", entriedService.paginateEntried(query));
				model.addAttribute("pageNo", query.getPageNo());
				model.addAttribute("pageSize", query.getPageSize());
			}
		}
		return "/requirement/status";
	}
	
	private boolean validate() {
		return true;
	}
}
