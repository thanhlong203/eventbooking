/**
 * 
 */
package yav.offshore.eventbooking.misc;

import java.security.SecureRandom;

/**
 * @author DEV-LongDT
 *
 */
public class PassWordGenerator {
	public static String generate(int length) {
		String characterSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < length; i++) {
		  int randomInt = new SecureRandom().nextInt(characterSet.length());
		  sb.append(characterSet.substring(randomInt, randomInt + 1));
		}
		return sb.toString();
	}
}
