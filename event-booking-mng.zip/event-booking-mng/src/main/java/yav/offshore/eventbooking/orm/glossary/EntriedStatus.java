package yav.offshore.eventbooking.orm.glossary;

import java.util.Map;

import yav.offshore.eventbooking.orm.PersistentEnum;
import yav.offshore.eventbooking.orm.PersistentEnums;

/**
 * 
 * @author DEV-LongDT
 */
public enum EntriedStatus implements PersistentEnum<Byte>{
	RESERVED((byte) 1, "予約済み"),
	CANCEL((byte) 2, "キャンセル");

	private static final Map<Byte, EntriedStatus> INDEX = PersistentEnums.index(EntriedStatus.class);

    //
    private final byte value;
    private final String displayName;
    
    private EntriedStatus(byte value, String displayName) {
    	this.value = value;
        this.displayName = displayName;
	}
	
    @Override
    public Byte getValue() {
        return this.value;
    }

    @Override
    public String getDisplayName() {
        return this.displayName;
    }

    @Override
    public Map<Byte, EntriedStatus> getAll() {
        return INDEX;
    }
    
    public static EntriedStatus parse(Byte value) {
        return value == null ? null : INDEX.get(value);
    }

}
