/**
 * 
 */
package yav.offshore.eventbooking.orm.entity;

/**
 * @author DEV-LongDT
 *
 */
public class NewAccount extends Account{
	private static final long serialVersionUID = -8817691699115539084L;
	private String newPassword;
	private String confirmPassword;

//	public NewAccount(Account account) {
//		this.setAccountId(account.getAccountId());
//		this.setActiveFlg(account.getActiveFlg());
//		this.setEmail(account.getEmail());
//		this.setFullName(account.getFullName());
//		this.setInsertDatetime(account.getInsertDatetime());
//		this.setPassword(account.getPassword());
//		this.setPasswordExpirePolicy(account.getPasswordExpirePolicy());
//		this.setPasswordExpriedTime(account.getPasswordExpriedTime());
//		this.setPasswordStatus(account.getPasswordStatus());
//		this.setRegisterDate(account.getRegisterDate());
//		this.setUpdateDatetime(account.getUpdateDatetime());
//	}

	/**
	 * @return the newPassword
	 */
	public String getNewPassword() {
		return newPassword;
	}

	/**
	 * @param newPassword the newPassword to set
	 */
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	/**
	 * @return the confirmPassword
	 */
	public String getConfirmPassword() {
		return confirmPassword;
	}

	/**
	 * @param confirmPassword the confirmPassword to set
	 */
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	
	
}
