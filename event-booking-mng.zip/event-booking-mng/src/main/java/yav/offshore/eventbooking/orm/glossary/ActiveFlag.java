package yav.offshore.eventbooking.orm.glossary;

import java.util.Map;

import yav.offshore.eventbooking.orm.PersistentEnum;
import yav.offshore.eventbooking.orm.PersistentEnums;

/**
 * 
 * @author DEV-LongDT
 */
public enum ActiveFlag implements PersistentEnum<Byte>{
	ACTIVE((byte) 1, "ACTIVE"),
	DEACTIVE((byte) 9, "DEACTIVE");

	private static final Map<Byte, ActiveFlag> INDEX = PersistentEnums.index(ActiveFlag.class);

    //
    private final byte value;
    private final String displayName;
    
    private ActiveFlag(byte value, String displayName) {
    	this.value = value;
        this.displayName = displayName;
	}
	
    @Override
    public Byte getValue() {
        return this.value;
    }

    @Override
    public String getDisplayName() {
        return this.displayName;
    }

    @Override
    public Map<Byte, ActiveFlag> getAll() {
        return INDEX;
    }
    
    public boolean isActive() {
    	return this == ACTIVE;
    }
    
    public boolean isSDeactive() {
    	return this == DEACTIVE;
    }
    public static ActiveFlag parse(Byte value) {
        return value == null ? null : INDEX.get(value);
    }

}
