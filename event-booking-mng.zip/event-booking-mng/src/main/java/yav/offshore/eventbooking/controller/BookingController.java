/**
 * 
 */
package yav.offshore.eventbooking.controller;

import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import yav.offshore.eventbooking.orm.Page;
import yav.offshore.eventbooking.orm.entity.Entried;
import yav.offshore.eventbooking.orm.entity.Location;
import yav.offshore.eventbooking.orm.glossary.EntriedStatus;
import yav.offshore.eventbooking.orm.query.EntriedQuery;

/**
 * @author DEV-LongDT
 *
 */
@Controller
@RequestMapping(value="/booking")
public class BookingController extends AbstractController{
	private static final Logger LOGGER = LoggerFactory.getLogger(BookingController.class);
	
	@GetMapping(value="/status")
	public String status(Model model, @RequestParam Map<String, String> reqParam) {
		List<Location> locations = locationService.getAll();
		model.addAttribute("locations", locations);
		EntriedStatus.RESERVED.getClass();
		if (reqParam.size() > 0) {
			if (validate(reqParam)) {
				EntriedQuery query = new EntriedQuery();
				if (!reqParam.containsKey("pageNo")) query.setPageNo(1);
				else query.setPageNo("".equals(reqParam.get("pageNo")) ? null : Integer.parseInt(reqParam.get("pageNo")));
				if (!reqParam.containsKey("pageSize")) query.setPageSize(25);
				else query.setPageSize("".equals(reqParam.get("pageSize")) ? null : Integer.parseInt(reqParam.get("pageSize")));
				query.setDateFrom("".equals(reqParam.get("datefrom"))? null : reqParam.get("datefrom"));
				query.setDateTo("".equals(reqParam.get("dateto"))? null : reqParam.get("dateto"));
				query.setLocationId("".equals(reqParam.get("location")) ? null : Integer.parseInt(reqParam.get("location")));
				query.setEntriesStatus("".equals(reqParam.get("status")) ? null : EntriedStatus.parse((byte) Integer.parseInt(reqParam.get("status"))));
				model.addAttribute("page", entriedService.paginateEntried(query));
				model.addAttribute("pageNo", query.getPageNo());
				model.addAttribute("pageSize", query.getPageSize());
				model.addAllAttributes(reqParam);
			}
		}
		return "/booking/status";
	}
	
	@GetMapping(value="/csv")
	public void getCsv (Model model, HttpServletResponse response, @RequestParam Map<String, String> reqParam) {
		try {
			boolean hasMorePage = true;  int pageNo = 1;StringBuffer csvData = new StringBuffer(" ");
            StringBuilder sbTitle = new StringBuilder();
            sbTitle.append("開催場所").append(",");
            sbTitle.append("日程").append(",");
            sbTitle.append("時間").append(",");
            sbTitle.append("名前").append(",");
            sbTitle.append("メールアドレス").append(",");
            sbTitle.append("年齢").append(",");
            sbTitle.append("エントリー日").append(",");
            sbTitle.append("ステータス").append(",");
            sbTitle.append("\n");
            StringBuffer sb = new StringBuffer("");
            sb.append(sbTitle);
            while (hasMorePage){
            	if (validate(reqParam)) {
            		EntriedQuery query = new EntriedQuery();
            		query.setDateFrom("".equals(reqParam.get("datefrom"))? null : reqParam.get("datefrom"));
    				query.setDateTo("".equals(reqParam.get("dateto"))? null : reqParam.get("dateto"));
    				query.setLocationId("".equals(reqParam.get("location")) ? null : Integer.parseInt(reqParam.get("location")));
    				query.setEntriesStatus("".equals(reqParam.get("status")) ? null : EntriedStatus.parse((byte) Integer.parseInt(reqParam.get("status"))));
    				query.setPageNo(pageNo);
    				query.setPageSize(200);
    				Page<Entried> page = entriedService.paginateEntried(query);
    				hasMorePage = page.hasMorePage();
    				pageNo ++;
    				for (Entried e : page.getRecords()) {
    					csvData.append(e.getLocationName()).append(",")
    						   .append(e.getScheduleDate()).append(",")
    						   .append(e.getFromTime()).append("~").append(e.getToTime()).append(",")
    						   .append(e.getAttendee().getFullName()).append(",")
    						   .append(e.getAttendee().getEmail()).append(",")
    						   .append(e.getAttendeeAge()).append(",")
    						   .append(e.getEntriedDatetime()).append(",")
    						   .append(e.getStatus().getDisplayName()).append(",")
    						   .append("\n");
    				}
            	} else hasMorePage = false;
            }
            sb.append(csvData);
            OutputStream os = response.getOutputStream();
            String headerValue = String.format("attachment; filename=\"%s\"","booking.csv");
            response.setContentType("text/csv;charset=UTF-8");
    	    response.setHeader("Content-Disposition", headerValue);
    	    byte b[] = {(byte)0xEF, (byte)0xBB, (byte)0xBF};
    	    os.write(b);
    	    os.write(new String(sb).getBytes(Charset.forName("UTF-8")));
    	    os.flush();
		} catch (Exception e) {
			LOGGER.error("fail to export csv" + e);
		}
	}
	
	private boolean validate(Map<String , String> map) {
		return true;
	}
	
	@ModelAttribute("entriedStatus")
	public EntriedStatus[] getSatus() {
		return EntriedStatus.values();
	}
}
