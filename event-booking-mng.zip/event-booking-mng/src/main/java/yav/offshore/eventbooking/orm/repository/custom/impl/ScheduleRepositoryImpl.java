/**
 * 
 */
package yav.offshore.eventbooking.orm.repository.custom.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import yav.offshore.eventbooking.orm.entity.Schedule;
import yav.offshore.eventbooking.orm.query.ScheduleQuery;
import yav.offshore.eventbooking.orm.repository.custom.ScheduleRepositoryCustom;

/**
 * @author DEV-LongDT
 *
 */

@Repository
@Transactional(readOnly=true)
public class ScheduleRepositoryImpl implements ScheduleRepositoryCustom{
	@PersistenceContext
    EntityManager entityManager;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Schedule> paginateSchedule(ScheduleQuery query) {
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT s FROM Schedule s WHERE s.activeFlg = yav.offshore.eventbooking.orm.glossary.ActiveFlag.ACTIVE");
		sql.append(getSqlQuery(query));
		Query sqlQuery = entityManager.createQuery(sql.toString());
		sqlQuery.setFirstResult(query.getOffset());
		sqlQuery.setMaxResults(query.getPageSize());
		return sqlQuery.getResultList();
	}
	
	@Override
	public Long countSchedule(ScheduleQuery query) {
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT COUNT(s) FROM Schedule s WHERE s.activeFlg = yav.offshore.eventbooking.orm.glossary.ActiveFlag.ACTIVE");
		sql.append(getSqlQuery(query));
		Query sqlQuery = entityManager.createQuery(sql.toString());
		return (Long) sqlQuery.getSingleResult();
	}
	
	private String getSqlQuery(ScheduleQuery query) {
		StringBuffer sql = new StringBuffer();
		if (query.getDateFrom() != null) sql.append(" AND s.date >= ").append(query.getDateFrom());
		if (query.getDateTo() != null) sql.append(" AND s.date <=").append(query.getDateTo());
		if (query.getLocationId() != null) sql.append(" AND s.location.id = ").append(query.getLocationId());
		return sql.toString();
	}

}
