/**
 * 
 */
package yav.offshore.eventbooking.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import yav.offshore.eventbooking.misc.PassWordGenerator;
import yav.offshore.eventbooking.orm.entity.Account;
import yav.offshore.eventbooking.orm.glossary.ActiveFlag;
import yav.offshore.eventbooking.orm.query.AccountQuery;
import yav.offshore.eventbooking.orm.service.AccountService;
import yav.offshore.eventbooking.validator.AccountValidator;

/**
 * @author DEV-LongDT
 *
 */

@Controller
@RequestMapping(value="/account")
public class AccountController extends AbstractController{
	
	@InitBinder
	public void initBinder(DataBinder binder) {
		binder.setValidator(new AccountValidator(accountService));
	}
	
	@GetMapping(value="")
	public String index(Model model, @RequestParam(value = "pageNo", required = false) Integer pageNo, @RequestParam(value = "pageSize", required = false) Integer pageSize) {
		AccountQuery query = new AccountQuery();
		query.setPageNo(pageSize == null ? 1 : pageNo);
		query.setPageSize(pageSize == null ? 25 : pageSize);
		model.addAttribute("page", accountService.paginateAccount(query));
		model.addAttribute("pageSize", query.getPageNo());
		model.addAttribute("pageSize", query.getPageSize());
		return "account/index";
	}
	
	@GetMapping(value="/add")
	public String addAccount(Model model) {
		model.addAttribute("account", new Account());
		return "/account/regist";
	}
	
	@PostMapping(value="/add")
	public String add(@ModelAttribute("account") @Valid Account account, BindingResult bindingResult, Model model) {
		if (bindingResult.hasErrors()) {
			model.addAttribute("account", account);
			return "/account/regist";
		} else {
			account.setActiveFlg(ActiveFlag.ACTIVE);
			String password = PassWordGenerator.generate(8);
			account.setPassword(password);
			accountService.save(account);
			sendEmail(account.getEmail(), "Regist Success", "Your password is " + password, null);
		}
		return "redirect:/account";
	}
}
