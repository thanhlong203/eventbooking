/**
 * 
 */
package yav.offshore.eventbooking.orm.entity.converter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import yav.offshore.eventbooking.orm.glossary.UsePersonalInfo;

/**
 * @author DEV-LongDT
 *
 */
@Converter(autoApply = true)
public class UserPersonalInfoConverter implements AttributeConverter<UsePersonalInfo, Integer> {

	@Override
	public Integer convertToDatabaseColumn(UsePersonalInfo usePersonalInfo) {
		return usePersonalInfo.getValue().intValue();
	}

	@Override
	public UsePersonalInfo convertToEntityAttribute(Integer dbData) {
		return UsePersonalInfo.parse(dbData.byteValue());
	}

}
