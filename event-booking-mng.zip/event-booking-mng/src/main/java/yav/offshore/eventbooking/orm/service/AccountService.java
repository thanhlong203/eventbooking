package yav.offshore.eventbooking.orm.service;

import yav.offshore.eventbooking.orm.Page;
import yav.offshore.eventbooking.orm.entity.Account;
import yav.offshore.eventbooking.orm.query.AccountQuery;

public interface AccountService {
	void insertOrUpdate(Account account);
	Account authenLogin(String email, String password);
	Account getById(int id);
	Account getByEmail(String email);
	Page<Account> paginateAccount(AccountQuery query);
	void save(Account account);
}
