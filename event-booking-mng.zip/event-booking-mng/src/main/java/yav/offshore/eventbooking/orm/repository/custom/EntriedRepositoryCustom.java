/**
 * 
 */
package yav.offshore.eventbooking.orm.repository.custom;

import java.util.List;

import yav.offshore.eventbooking.orm.entity.Entried;
import yav.offshore.eventbooking.orm.query.EntriedQuery;

/**
 * @author DEV-LongDT
 *
 */
public interface EntriedRepositoryCustom {
	List<Entried> getEntried(EntriedQuery query);
	Long countEntried(EntriedQuery query);
}
