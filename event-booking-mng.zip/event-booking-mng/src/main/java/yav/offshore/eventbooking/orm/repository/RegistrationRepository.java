package yav.offshore.eventbooking.orm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import yav.offshore.eventbooking.orm.entity.Registration;

/**
 * @author DEV-LongDT
 *
 */
@Repository
public interface RegistrationRepository extends CrudRepository<Registration, Integer> {
	@Query("SELECT r FROM Registration r WHERE LOWER(r.locationId) = LOWER(:locationId)")
	List<Registration> getByLocationId(@Param("locationId") int id);
}
