/**
 * 
 */
package yav.offshore.eventbooking.orm.repository.custom;

import java.util.List;

import yav.offshore.eventbooking.orm.entity.Schedule;
import yav.offshore.eventbooking.orm.query.ScheduleQuery;

/**
 * @author DEV-LongDT
 *
 */
public interface ScheduleRepositoryCustom {
	List<Schedule> paginateSchedule(ScheduleQuery query);
	Long countSchedule(ScheduleQuery query);
}
