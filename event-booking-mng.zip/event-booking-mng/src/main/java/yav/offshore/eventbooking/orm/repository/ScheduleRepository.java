/**
 * 
 */
package yav.offshore.eventbooking.orm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import yav.offshore.eventbooking.orm.entity.Schedule;
import yav.offshore.eventbooking.orm.repository.custom.ScheduleRepositoryCustom;

/**
 * @author DEV-LongDT
 *
 */

@Repository
public interface ScheduleRepository extends CrudRepository<Schedule, Integer>, ScheduleRepositoryCustom {
	@Query("select s from Schedule s left join s.location l where l.locationId = :locationId")
	List<Schedule> getLocationSchedule(@Param("locationId") int locationId);
}
