/**
 * 
 */
package yav.offshore.eventbooking.orm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import yav.offshore.eventbooking.orm.Page;
import yav.offshore.eventbooking.orm.entity.Schedule;
import yav.offshore.eventbooking.orm.impl.XPage;
import yav.offshore.eventbooking.orm.query.ScheduleQuery;
import yav.offshore.eventbooking.orm.repository.ScheduleRepository;
import yav.offshore.eventbooking.orm.service.ScheduleService;

/**
 * @author DEV-LongDT
 *
 */
@Service
public class ScheduleServiceImpl implements ScheduleService{
	@Autowired
	private ScheduleRepository scheduleRepository;
	
	@Override
	public List<Schedule> getScheduleLocation(int locationId) {
		return scheduleRepository.getLocationSchedule(locationId);
	}

	@Override
	public Page<Schedule> paginateSchedule(ScheduleQuery query) {
		final XPage<Schedule> r = new XPage<Schedule>(query.getPageNo(), query.getPageSize());
		r.setRecords(scheduleRepository.paginateSchedule(query));
		r.setTotalRecordCount(scheduleRepository.countSchedule(query));
		return r;
	}

	@Override
	public void save(Schedule schedule) {
		scheduleRepository.save(schedule);
		
	}

	@Override
	public void saveMany(Iterable<Schedule> sIterable) {
		scheduleRepository.save(sIterable);
	}
	
	
}
