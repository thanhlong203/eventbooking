/**
 * 
 */
package yav.offshore.eventbooking.config;

import org.sitemesh.builder.SiteMeshFilterBuilder;
import org.sitemesh.config.ConfigurableSiteMeshFilter;

/**
 * @author DEV-LongDT
 *
 */
public class WebSiteMeshFilter extends ConfigurableSiteMeshFilter{
	@Override
	protected void applyCustomConfiguration(SiteMeshFilterBuilder builder) {
		builder.addDecoratorPath("/*", "/WEB-INF/jsp/default.jsp");
		builder.addDecoratorPath("/login", "/WEB-INF/jsp/misc/loginLayout.jsp");
		builder.addDecoratorPath("/account/change-password", "/WEB-INF/jsp/misc/loginLayout.jsp");
		builder.addDecoratorPath("/account/forgot-password", "/WEB-INF/jsp/misc/loginLayout.jsp");
		builder.addDecoratorPath("/error", "/WEB-INF/jsp/misc/loginLayout.jsp");
	}
}