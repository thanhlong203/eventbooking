/**
 * 
 */
package yav.offshore.eventbooking.controller;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import yav.offshore.eventbooking.controller.support.anotation.DoNotHaveToLogin;
import yav.offshore.eventbooking.controller.support.anotation.LoginAccount;
import yav.offshore.eventbooking.orm.entity.Account;
import yav.offshore.eventbooking.orm.glossary.PasswordExpirePolicy;
import yav.offshore.eventbooking.orm.glossary.PasswordStatus;
import yav.offshore.eventbooking.validator.LoginValidator;

/**
 * @author DEV-LongDT
 *
 */

@Controller
public class LoginController extends AbstractController{
	
	@InitBinder
	public void initBinder(DataBinder binder) {
		binder.setValidator(new LoginValidator());
	}
	
	@GetMapping(value="/login")
	@DoNotHaveToLogin
	public String login(Model model, @LoginAccount Account account) {
		if (account != null) {
			if (account.getPasswordStatus() == PasswordStatus.INITIAL) return "redirect:/change-password";
			return "redirect:/policy";
		}
		model.addAttribute("account", new Account());
		return "misc/login";
	}
	
	@PostMapping(value="/login")
	@DoNotHaveToLogin
	public String login(@ModelAttribute("account") @Valid Account account, BindingResult bindingResult, HttpSession session, Model model) {
		if (bindingResult.hasErrors()) {
			model.addAttribute("account", account);
			return "misc/login";
		}
		Account loginAccount = accountService.authenLogin(account.getEmail(), account.getPassword());
		if (loginAccount != null) {
			session.setAttribute(CURRENT_USER, loginAccount);
			if (loginAccount.getPasswordStatus() == PasswordStatus.INITIAL || (loginAccount.getPasswordExpirePolicy() != PasswordExpirePolicy.NEVER && loginAccount.getPasswordExpriedTime().before(new Date()))) {
				loginAccount.setPasswordStatus(PasswordStatus.EXPIRED);
				accountService.insertOrUpdate(loginAccount);
			}
			return "redirect:/schedule";
		}
		model.addAttribute("account", account);
		return "misc/login";
	}
	
	@RequestMapping(value="/logout")
	@DoNotHaveToLogin
	public String logout(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		if (session != null) session.invalidate();
		return "redirect:/login";
	}
}
