/**
 * 
 */
package yav.offshore.eventbooking.orm.entity.converter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import yav.offshore.eventbooking.orm.glossary.EntriedStatus;

/**
 * @author DEV-LongDT
 *
 */
@Converter(autoApply = true)
public class EntriesStatusConverter implements AttributeConverter<EntriedStatus, Integer> {

	@Override
	public Integer convertToDatabaseColumn(EntriedStatus entriesStatus) {
		return entriesStatus.getValue().intValue();
	}

	@Override
	public EntriedStatus convertToEntityAttribute(Integer dbData) {
		return EntriedStatus.parse(dbData.byteValue());
	}

}
