/**
 * 
 */
package yav.offshore.eventbooking.orm.entity.converter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import yav.offshore.eventbooking.orm.glossary.PasswordStatus;

/**
 * @author DEV-LongDT
 *
 */
@Converter(autoApply = true)
public class PasswordStatusConverter implements AttributeConverter<PasswordStatus, Integer> {

	@Override
	public Integer convertToDatabaseColumn(PasswordStatus passwordStatus) {
		return passwordStatus.getValue().intValue();
	}

	@Override
	public PasswordStatus convertToEntityAttribute(Integer dbData) {
		return PasswordStatus.parse(dbData.byteValue());
	}

}
