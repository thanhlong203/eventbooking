/**
 * 
 */
package yav.offshore.eventbooking.orm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import yav.offshore.eventbooking.orm.entity.Location;
import yav.offshore.eventbooking.orm.repository.custom.LocationRepositoryCustom;

/**
 * @author DEV-LongDT
 *
 */
@Repository
public interface LocationRepository extends CrudRepository<Location, Integer>, LocationRepositoryCustom {
	@Query("select l from Location l where l.locationId = :locationId and l.activeFlg = yav.offshore.eventbooking.orm.glossary.ActiveFlag.ACTIVE")
	Location findLocationById(@Param("locationId") Integer locationId);
	
	@Query("select l from Location l where l.activeFlg = yav.offshore.eventbooking.orm.glossary.ActiveFlag.ACTIVE")
	List<Location> findAll();
}
	