package yav.offshore.eventbooking.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;

import yav.offshore.eventbooking.orm.service.AccountService;
import yav.offshore.eventbooking.orm.service.EntriedService;
import yav.offshore.eventbooking.orm.service.LocationService;
import yav.offshore.eventbooking.orm.service.RegistrationService;
import yav.offshore.eventbooking.orm.service.ScheduleService;

@Controller
public class AbstractController {
	protected final String CURRENT_USER = "current_user";
	protected final String LOGIN_PAGE = "policy";
	
	@Autowired
	private JavaMailSender emailSender;
	
	@Autowired
	protected RegistrationService registrationService;

	@Autowired
	protected AccountService accountService;
	
	@Autowired
	protected LocationService locationService;

	@Autowired 
	protected ScheduleService scheduleService;
	
	@Autowired
	protected EntriedService entriedService;
	
	@Autowired
	protected MessageSource messageSource;
	
	protected static final Logger LOGGER = LoggerFactory.getLogger(AbstractController.class);
	
	@ExceptionHandler(value = Exception.class)
	public String error(Exception e) {
		LOGGER.error(e.getMessage());
		e.printStackTrace();
		return "/error";
	}
	
	protected void sendEmail(String to, String subject, String content, String cc) {
		SimpleMailMessage message = new SimpleMailMessage(); 
		if (cc != null) message.setCc(cc);
        message.setTo(to);
        message.setSubject(subject); 
        message.setText(content);
        emailSender.send(message);
	}
	
	protected boolean isDate(String dateToValidate) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyy-mm-dd"); 
		try {
			sdf.parse(dateToValidate);
		} catch (ParseException e) {
			return false;
		}
		return true;
	}
}
