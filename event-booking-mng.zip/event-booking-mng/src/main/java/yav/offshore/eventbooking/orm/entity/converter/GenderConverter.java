/**
 * 
 */
package yav.offshore.eventbooking.orm.entity.converter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import yav.offshore.eventbooking.orm.glossary.Gender;

/**
 * @author DEV-LongDT
 *
 */
@Converter(autoApply = true)
public class GenderConverter implements AttributeConverter<Gender, Integer> {

	@Override
	public Integer convertToDatabaseColumn(Gender gender) {
		return gender.getValue().intValue();
	}

	@Override
	public Gender convertToEntityAttribute(Integer dbData) {
		return Gender.parse(dbData.byteValue());
	}

}
